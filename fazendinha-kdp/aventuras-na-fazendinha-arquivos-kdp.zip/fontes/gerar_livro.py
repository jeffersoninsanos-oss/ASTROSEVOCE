#!/usr/bin/env python3
"""Gera ilustrações e arquivos de impressão para Aventuras na Fazendinha."""

from __future__ import annotations

import argparse
import base64
import io
import json
import math
import os
import shutil
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import cairosvg
from PIL import Image, ImageOps
from reportlab.lib.colors import HexColor, white
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parent
REFERENCE_DIR = ROOT.parents[1]
OUT = ROOT / "arquivos"
PNG_DIR = OUT / "ilustracoes_png"
SVG_DIR = OUT / "originais_svg"
DEFAULT_COVER_REFERENCE = REFERENCE_DIR / "Capa_Livro_para_Colorir_Dinossauros.jpg"
DEFAULT_COLORING_REFERENCE = REFERENCE_DIR / "ChatGPT Image 29 de jul. de 2026, 15_34_52 (1).png"
TITLE = "Aventuras na Fazendinha"
SUBTITLE = "25 bichinhos para colorir e se divertir"
PAGE_W_IN, PAGE_H_IN, DPI = 8.5, 11, 300
PNG_W, PNG_H = 2550, 3300
AI_MODEL = "gpt-image-2.5-sunburst"
VIEW_W, VIEW_H = 850, 1100
INK = "#171717"
STROKE = f'fill="white" stroke="{INK}" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round"'


def sun_clouds(seed: int) -> str:
    x = 720 if seed % 2 == 0 else 128
    y = 132 + (seed % 3) * 13
    return (
        f'<path d="M{x} {y-54}v-13m0 121v-13m54-41h13m-121 0h13m79-39 10-10m-86 86 10-10m66 0 10 10m-86-86 10 10" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
        f'<circle cx="{x}" cy="{y}" r="37" {STROKE}/>'
        f'<circle cx="{x-10}" cy="{y-4}" r="2.8" fill="{INK}"/><circle cx="{x+10}" cy="{y-4}" r="2.8" fill="{INK}"/>'
        f'<path d="M{x-9} {y+8}q9 10 18 0" fill="none" stroke="{INK}" stroke-width="2.5" stroke-linecap="round"/>'
        f'<path d="M{200+seed%5*60} 160q12-22 27-4 14-22 30 1 19-1 18 15h-75q-8-7 0-12Z" {STROKE}/>'
        f'<path d="M{420+seed%4*32} 105q11-20 25-3 13-21 27 1 17-1 18 14h-69q-8-7-1-12Z" {STROKE}/>'
        f'<path d="M{219+seed%5*60} 160h38m-9-5-7 4 7 4m210-58h40m-10-5-7 4 7 4" fill="none" stroke="{INK}" stroke-width="1.8"/>'
    )


def fence(seed: int = 0) -> str:
    y = 824 + seed % 3 * 5
    return (
        f'<path d="M45 {y+27}h760m-760 22h760" fill="none" stroke="{INK}" stroke-width="4"/>'
        + "".join(
            f'<path d="M{x} {y+62}v-80q0-12 12-12t12 12v80" {STROKE}/>'
            for x in range(78 + seed % 3 * 7, 790, 142)
        )
    )


def flowers(seed: int, y: int = 850) -> str:
    parts = []
    for i, x in enumerate((84, 166, 690, 770)):
        base = y + (i % 2) * 12
        top = base - 35 - ((seed + i) % 3) * 7
        parts.append(f'<path d="M{x} {base}q-5-23 0-43m0 31q-17-16-25-10 5 16 25 14m0-10q14-17 24-11-3 16-24 15" fill="none" stroke="{INK}" stroke-width="2.5" stroke-linecap="round"/>')
        petals = 5 + (seed + i) % 2
        parts.append(f'<g transform="translate({x} {top})">')
        for petal in range(petals):
            angle = math.tau * petal / petals
            px, py = 10 * math.cos(angle), 10 * math.sin(angle)
            parts.append(f'<ellipse cx="{px:.2f}" cy="{py:.2f}" rx="5.5" ry="8" transform="rotate({petal*360/petals:.1f} {px:.2f} {py:.2f})" {STROKE}/>')
        parts.append(f'<circle r="5.5" {STROKE}/></g>')
    return "".join(parts)


def barn() -> str:
    return (
        f'<path d="M70 400V265l113-91 113 91v135Z" {STROKE}/>'
        f'<path d="m55 270 128-106 128 106" fill="none" stroke="{INK}" stroke-width="5" stroke-linejoin="round"/>'
        f'<path d="M143 400V302q0-13 13-13h34q13 0 13 13v98m-60-50h60m-30-63v113" fill="none" stroke="{INK}" stroke-width="3"/>'
        f'<path d="M89 289h33v33H89zm161 0h33v33h-33z" {STROKE}/>'
    )


def tree(x: int, y: int, scale: float = 1) -> str:
    return (
        f'<g transform="translate({x} {y}) scale({scale})">'
        f'<path d="M0 95v-65m-23 65h46" fill="none" stroke="{INK}" stroke-width="5"/>'
        f'<circle cx="0" cy="-2" r="36" {STROKE}/><circle cx="-25" cy="22" r="25" {STROKE}/>'
        f'<circle cx="26" cy="22" r="25" {STROKE}/><path d="M-12 0q12-12 24 0M-39 26q14-13 27 0m20-1q12-12 27 0" fill="none" stroke="{INK}" stroke-width="2"/>'
        f'<path d="M-19 4q8-11 17-2m10 17q8-11 17-2" fill="none" stroke="{INK}" stroke-width="1.8"/>'
        f'<circle cx="-25" cy="16" r="5" {STROKE}/><circle cx="21" cy="8" r="5" {STROKE}/><circle cx="37" cy="30" r="5" {STROKE}/>'
        f'</g>'
    )


def hay(x: int, y: int, scale: float = 1) -> str:
    return (
        f'<g transform="translate({x} {y}) scale({scale})">'
        f'<path d="m0 0 24-39h64L112 0v42H0Z" {STROKE}/>'
        f'<path d="m24-39 24 81m40-81L64 42M10 15h92" fill="none" stroke="{INK}" stroke-width="2"/>'
        f'</g>'
    )


def pond(x: int, y: int, scale: float = 1) -> str:
    return (
        f'<g transform="translate({x} {y}) scale({scale})">'
        f'<path d="M-135 0q35-25 70 0t70 0 70 0 70 0q-30 47-140 47T-135 0Z" {STROKE}/>'
        f'<path d="M-79 14h42m42 0h52m29-14h28" fill="none" stroke="{INK}" stroke-width="2"/>'
        f'</g>'
    )


def body_shape(kind: str) -> str:
    if kind in {"sheep", "lamb"}:
        puffs = "".join(
            f'<circle cx="{x}" cy="{y}" r="{r}" {STROKE}/>'
            for x, y, r in (
                (-46, -22, 24), (-27, -42, 23), (0, -48, 25),
                (29, -39, 23), (49, -16, 23), (38, 13, 23),
                (8, 24, 25), (-23, 18, 24), (-48, 8, 20),
            )
        )
        return f'<g>{puffs}<ellipse cx="0" cy="-10" rx="50" ry="38" {STROKE}/></g>'
    if kind in {"rabbit"}:
        return f'<ellipse cx="-5" cy="0" rx="52" ry="39" {STROKE}/>'
    if kind in {"llama", "alpaca"}:
        return f'<ellipse cx="-2" cy="1" rx="54" ry="40" {STROKE}/><path d="M34-17q18-32 19-65l23-30q19 0 21 18l-18 20q4 33-10 61" {STROKE}/>'
    if kind in {"duck", "goose", "hen", "rooster", "turkey", "chicken"}:
        return f'<ellipse cx="-3" cy="0" rx="49" ry="38" {STROKE}/>'
    if kind == "cat":
        return f'<ellipse cx="-4" cy="0" rx="49" ry="35" {STROKE}/>'
    if kind == "dog":
        return f'<ellipse cx="-4" cy="0" rx="56" ry="38" {STROKE}/>'
    return f'<ellipse cx="-3" cy="0" rx="66" ry="39" {STROKE}/>'


def animal(kind: str, x: int, y: int, scale: float = 2.2, facing: int = 1, pose: int = 0) -> str:
    """Draw a friendly, open-line farm animal in a unique pose."""
    bird = kind in {"duck", "goose", "hen", "rooster", "turkey", "chicken"}
    head_x = 40 if facing > 0 else -48
    head_y = -48 if kind in {"horse", "pony", "foal", "donkey"} else -45
    body = body_shape(kind)

    legs = (
        f'<path d="M-48 21v{38+pose%3*7}q0 8 9 8h7M-19 28v53q0 8 9 8h7'
        f'M26 28v{48-pose%3*5}q0 8 9 8h7M49 18v48q0 8 9 8h7" '
        f'fill="none" stroke="{INK}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>'
    )
    tail = f'<path d="M-67-12q-27-5-25-34m0 0q-14 3-10 18" fill="none" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>'
    markings = ""
    head_extra = ""
    features = ""

    if kind in {"cow", "calf"}:
        head_x = 45
        markings = (
            f'<path d="M-47-21q17-24 35-6l-9 24-28 3Zm50-11q19-19 38-4l-7 22-26 8Z" {STROKE}/>'
            f'<path d="M-15 17q16-10 28 1" fill="none" stroke="{INK}" stroke-width="2.5"/>'
        )
        head_extra = (
            f'<path d="M{head_x-19}-67q-20-24-30-9l16 21m{head_x+13}-12q13-25 26-11l-15 22" {STROKE}/>'
            f'<path d="M{head_x-11}-68q2-21 12-25m9 23q18-21 23-8" fill="none" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>'
            f'<ellipse cx="{head_x+3}" cy="-27" rx="23" ry="17" {STROKE}/>'
            f'<circle cx="{head_x-3}" cy="-29" r="2.5" fill="{INK}"/><circle cx="{head_x+10}" cy="-29" r="2.5" fill="{INK}"/>'
        )
        features = '<path d="M-25-39q0-19 16-16m40 5q16-12 24 5" fill="none" stroke="#171717" stroke-width="2.5"/>'
    elif kind in {"horse", "pony", "foal"}:
        head_x = 51
        head_extra = (
            f'<path d="M29-25q20-33 20-68l23-26q17 2 17 20L72-79q4 33-12 59" {STROKE}/>'
            f'<path d="M45-84q-17-17-4-31m10 30q-5-24 12-29m-8 30q8-22 26-17" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
            f'<ellipse cx="72" cy="-99" rx="18" ry="22" {STROKE}/>'
            f'<path d="M85-90q23 2 17 15-6 7-19-2" {STROKE}/>'
            f'<circle cx="77" cy="-105" r="2.5" fill="{INK}"/>'
        )
        tail = '<path d="M-65-5q-32 5-27 32m2-18q-16 2-17 17m19-8q-8 14-5 24" fill="none" stroke="#171717" stroke-width="4" stroke-linecap="round"/>'
        features = '<path d="M-30-15q25-13 48-4" fill="none" stroke="#171717" stroke-width="2"/>'
    elif kind == "donkey":
        head_x = 54
        head_extra = (
            f'<path d="M{head_x-8}-63q-14-48-29-48-12 10 5 56m27-6q15-52 29-48 12 11-7 59" {STROKE}/>'
            f'<ellipse cx="{head_x}" cy="-42" rx="25" ry="32" {STROKE}/><ellipse cx="{head_x+13}" cy="-19" rx="19" ry="13" {STROKE}/>'
            f'<circle cx="{head_x+5}" cy="-48" r="2.5" fill="{INK}"/>'
        )
    elif kind == "pig":
        head_x = 45
        tail = '<path d="M-66-8q-29 2-17 21 12 15 20-3-7-10-12-2" fill="none" stroke="#171717" stroke-width="4" stroke-linecap="round"/>'
        head_extra = (
            f'<path d="M{head_x-17}-62q-6-35 16-22l11 22m4 0q18-31 28-14l-11 24" {STROKE}/>'
            f'<ellipse cx="{head_x}" cy="-40" rx="27" ry="28" {STROKE}/>'
            f'<ellipse cx="{head_x+12}" cy="-27" rx="20" ry="14" {STROKE}/>'
            f'<circle cx="{head_x+4}" cy="-30" r="2.5" fill="{INK}"/><circle cx="{head_x+18}" cy="-30" r="2.5" fill="{INK}"/>'
            f'<circle cx="{head_x+7}" cy="-51" r="2.5" fill="{INK}"/>'
        )
    elif kind in {"sheep", "lamb"}:
        head_x = 54
        head_extra = (
            f'<ellipse cx="{head_x}" cy="-42" rx="21" ry="27" {STROKE}/>'
            f'<path d="M{head_x-14}-60q-18-21-26-5l12 16m30-10q19-20 25-3l-15 15" {STROKE}/>'
            f'<circle cx="{head_x-5}" cy="-47" r="2.7" fill="{INK}"/><circle cx="{head_x+8}" cy="-47" r="2.7" fill="{INK}"/>'
            f'<path d="M{head_x-3}-35q6 6 12 0" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
    elif kind in {"goat", "kid"}:
        head_x = 48
        head_extra = (
            f'<ellipse cx="{head_x}" cy="-40" rx="23" ry="27" {STROKE}/>'
            f'<path d="M{head_x-14}-59q-9-37 5-40l7 36m16 2q20-33 26-18l-17 24" {STROKE}/>'
            f'<path d="M{head_x-4}-20q4 25 13 1" {STROKE}/>'
            f'<path d="M{head_x-10}-48q8-5 13 0m4 0q8-5 13 0" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
    elif kind in {"duck", "goose"}:
        head_x = 36
        neck_h = 43 if kind == "duck" else 60
        head_extra = (
            f'<path d="M28-18q8-25 9-{neck_h}" fill="none" stroke="{INK}" stroke-width="11"/>'
            f'<circle cx="{head_x}" cy="{-neck_h-20}" r="22" {STROKE}/>'
            f'<path d="M{head_x+19} {-neck_h-23}q24 0 27 9-14 9-27 4Z" {STROKE}/>'
            f'<circle cx="{head_x+5}" cy="{-neck_h-25}" r="2.5" fill="{INK}"/>'
            f'<path d="M-17-3q18-24 34-2-15 14-34 2Z" {STROKE}/>'
            f'<path d="M-15 36v22m19-20v20m-10 0-9 7m9-7 9 7" fill="none" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
        )
        legs = ""
        tail = ""
        body = f'<ellipse cx="-3" cy="0" rx="49" ry="34" {STROKE}/>'
        features = ""
    elif kind in {"hen", "chicken", "rooster", "turkey"}:
        head_x = 40
        head_extra = (
            f'<path d="M{head_x-10}-62q-6-16 1-19 8-11 13 0 10-13 15-3 9-5 10 5l-5 17" {STROKE}/>'
            f'<circle cx="{head_x}" cy="-43" r="23" {STROKE}/>'
            f'<path d="M{head_x+19}-48q21 0 26 9-13 9-27 4Z" {STROKE}/>'
            f'<circle cx="{head_x+7}" cy="-49" r="2.5" fill="{INK}"/>'
        )
        if kind == "rooster":
            tail = '<path d="M-47-5q-40-55-39-5 10 17 29 18m-15-51q1-35 23-6" fill="none" stroke="#171717" stroke-width="4"/>'
        elif kind == "turkey":
            tail = (
                '<path d="M-41-12q-67-80-48-92 35-5 57 70m-18-73q40-38 51 9l-25 66m5-78q48-8 42 39l-34 39" fill="white" stroke="#171717" stroke-width="3"/>'
            )
        legs = '<path d="M-10 32v25m22-25v25m-22 0-13 8m13-8 12 8m10-8 13 8m-13-8 12-8" fill="none" stroke="#171717" stroke-width="3" stroke-linecap="round"/>'
        body = f'<ellipse cx="-5" cy="0" rx="48" ry="39" {STROKE}/><path d="M-26-1q22-23 43 0-21 20-43 0Z" {STROKE}/>'
        features = ""
        tail = ""
        if kind in {"hen", "chicken"}:
            head_extra += '<path d="M-36 35q-8 10-16 1m16 5q-8 10-16 2" fill="none" stroke="#171717" stroke-width="3"/>'
    elif kind == "rabbit":
        head_x = 45
        head_extra = (
            f'<path d="M{head_x-13}-55q-25-81-4-83 22 1 18 80m5 1q-2-83 19-82 21 8 4 87" {STROKE}/>'
            f'<ellipse cx="{head_x}" cy="-40" rx="25" ry="24" {STROKE}/>'
            f'<circle cx="{head_x-7}" cy="-44" r="2.5" fill="{INK}"/><circle cx="{head_x+8}" cy="-44" r="2.5" fill="{INK}"/>'
            f'<path d="M{head_x-2}-35q6 5 12 0m-6 1v7m0 0q-8 7-13 1m13-1q8 7 13 1" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
        tail = '<circle cx="-57" cy="6" r="14" fill="white" stroke="#171717" stroke-width="3"/>'
        legs = '<path d="M-37 22q-5 41 12 43h24m-2-36q0 35 15 36h27" fill="none" stroke="#171717" stroke-width="6" stroke-linecap="round"/>'
    elif kind == "cat":
        head_x = 46
        head_extra = (
            f'<path d="M{head_x-22}-51l-4-34 28 18m5 16 19-32 4 37" {STROKE}/>'
            f'<circle cx="{head_x}" cy="-41" r="27" {STROKE}/>'
            f'<path d="M{head_x-14}-46v-1m27 1v-1m-21 16q8 8 16 0m-21-5-19-3m19 8-21 3m46-8 20-3m-20 8 21 3" fill="none" stroke="#171717" stroke-width="2.2" stroke-linecap="round"/>'
        )
        tail = '<path d="M-66-6q-42-34-47 4t-17 0" fill="none" stroke="#171717" stroke-width="5" stroke-linecap="round"/>'
    elif kind == "dog":
        head_x = 48
        head_extra = (
            f'<ellipse cx="{head_x}" cy="-40" rx="27" ry="28" {STROKE}/>'
            f'<path d="M{head_x-18}-54q-32-37-35-5 3 28 24 27m45-27q25-32 31-4-3 26-24 30" {STROKE}/>'
            f'<ellipse cx="{head_x+8}" cy="-27" rx="15" ry="11" {STROKE}/>'
            f'<circle cx="{head_x+12}" cy="-29" r="3" fill="{INK}"/>'
            f'<circle cx="{head_x+5}" cy="-47" r="2.5" fill="{INK}"/>'
        )
        tail = '<path d="M-64-7q-32-16-30-37m-1 14q-15-8-22 1" fill="none" stroke="#171717" stroke-width="5" stroke-linecap="round"/>'
        features = '<path d="M3 32q22 9 44-1m-37-5 3 10m25-10-3 10" fill="none" stroke="#171717" stroke-width="2.5"/>'
    elif kind in {"llama", "alpaca"}:
        head_x = 66
        head_extra = (
            f'<path d="M{head_x-9}-99v-29q-14-25-23-11l10 35m25 4 12-29q18-14 21 3l-16 29" {STROKE}/>'
            f'<ellipse cx="{head_x}" cy="-84" rx="20" ry="25" {STROKE}/>'
            f'<circle cx="{head_x+5}" cy="-89" r="2.5" fill="{INK}"/>'
            f'<path d="M{head_x+8}-71q4 8 9-1" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
        legs = '<path d="M-38 26v43q0 9 10 9h12m18-47v39q0 9 10 9h13m-4-51v48q0 9 10 9h10m20-46v37q0 9 10 9h10" fill="none" stroke="#171717" stroke-width="6" stroke-linecap="round"/>'
        features = '<path d="M-42-14q15-17 28-2m4 4q14-15 28-2" fill="none" stroke="#171717" stroke-width="2"/>'
        if kind == "alpaca":
            head_extra += f'<path d="M{head_x-10}-102q20-23 37-2" fill="none" stroke="#171717" stroke-width="6"/>'
    else:
        head_extra = f'<circle cx="{head_x}" cy="-43" r="25" {STROKE}/>'

    # Keep one large, friendly, readable face on every animal.
    face_x, face_y = head_x, -43
    if kind in {"horse", "pony", "foal"}:
        face_x, face_y = 72, -99
    elif kind == "donkey":
        face_x, face_y = 54, -42
    elif kind in {"sheep", "lamb"}:
        face_x, face_y = 54, -42
    elif kind in {"goat", "kid"}:
        face_x, face_y = 48, -40
    elif kind in {"duck", "goose"}:
        face_x, face_y = 36, -neck_h-20
    elif kind in {"hen", "chicken", "rooster", "turkey"}:
        face_x, face_y = 40, -43
    elif kind == "rabbit":
        face_x, face_y = 45, -40
    elif kind == "cat":
        face_x, face_y = 46, -41
    elif kind == "dog":
        face_x, face_y = 48, -40
    elif kind in {"llama", "alpaca"}:
        face_x, face_y = 66, -84
    eye_y = face_y - 8
    eye_x = face_x + 4
    eyes = (
        f'<ellipse cx="{eye_x}" cy="{eye_y}" rx="9" ry="11" fill="white" stroke="{INK}" stroke-width="2.5"/>'
        f'<circle cx="{eye_x+2}" cy="{eye_y+2}" r="5" fill="{INK}"/>'
        f'<circle cx="{eye_x+3.5}" cy="{eye_y}" r="1.8" fill="white"/>'
        f'<path d="M{eye_x-9} {eye_y-13}q8-7 16 0" fill="none" stroke="{INK}" stroke-width="2.5" stroke-linecap="round"/>'
    )
    second_eye = ""
    if kind in {"cow", "calf"}:
        muzzle = (
            f'<ellipse cx="{face_x+5}" cy="-27" rx="22" ry="15" fill="white" stroke="{INK}" stroke-width="2.8"/>'
            f'<ellipse cx="{face_x-2}" cy="-28" rx="2.4" ry="3" fill="{INK}"/>'
            f'<ellipse cx="{face_x+11}" cy="-28" rx="2.4" ry="3" fill="{INK}"/>'
            f'<path d="M{face_x-2}-20q8 8 16 0" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
    elif kind == "pig":
        muzzle = (
            f'<ellipse cx="{face_x+10}" cy="-27" rx="21" ry="14" fill="white" stroke="{INK}" stroke-width="2.8"/>'
            f'<ellipse cx="{face_x+4}" cy="-27" rx="2.5" ry="4" fill="{INK}"/>'
            f'<ellipse cx="{face_x+17}" cy="-27" rx="2.5" ry="4" fill="{INK}"/>'
        )
    elif kind in {"horse", "pony", "foal"}:
        muzzle = (
            f'<ellipse cx="87" cy="-79" rx="16" ry="11" fill="white" stroke="{INK}" stroke-width="2.5"/>'
            '<circle cx="92" cy="-80" r="2" fill="#171717"/>'
        )
    elif kind == "donkey":
        muzzle = f'<ellipse cx="{face_x+13}" cy="-19" rx="17" ry="11" fill="white" stroke="{INK}" stroke-width="2.5"/>'
    elif kind in {"sheep", "lamb", "goat", "kid"}:
        muzzle = (
            f'<ellipse cx="{face_x+7}" cy="-27" rx="15" ry="10" fill="white" stroke="{INK}" stroke-width="2.2"/>'
            f'<circle cx="{face_x+12}" cy="-30" r="2.4" fill="{INK}"/>'
        )
    elif kind in {"duck", "goose", "hen", "chicken", "rooster", "turkey"}:
        muzzle = ""
    elif kind == "cat":
        muzzle = (
            f'<path d="m{face_x} {-31} 5 4-5 4-5-4Z" fill="white" stroke="{INK}" stroke-width="1.8"/>'
            f'<path d="M{face_x} -23q7 8 14 0m-16-5-18-3m18 8-20 2m34-7 18-3m-18 8 20 2" fill="none" stroke="{INK}" stroke-width="1.8"/>'
        )
    elif kind == "dog":
        muzzle = (
            f'<ellipse cx="{face_x+8}" cy="-25" rx="16" ry="12" fill="white" stroke="{INK}" stroke-width="2.2"/>'
            f'<ellipse cx="{face_x+12}" cy="-30" rx="4" ry="3" fill="{INK}"/>'
            f'<path d="M{face_x+2}-20q8 7 15-1" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
    elif kind in {"llama", "alpaca"}:
        muzzle = (
            f'<ellipse cx="{face_x+6}" cy="-68" rx="13" ry="9" fill="white" stroke="{INK}" stroke-width="2"/>'
            f'<circle cx="{face_x+10}" cy="-70" r="2" fill="{INK}"/>'
            f'<path d="M{face_x+2}-61q6 5 12 0" fill="none" stroke="{INK}" stroke-width="2"/>'
        )
    else:
        muzzle = f'<path d="M{face_x} {face_y+11}q7 7 14 0" fill="none" stroke="{INK}" stroke-width="2.5"/>'
    cheeks = (
        f'<path d="M{face_x-24} {face_y+8}q6-4 12 0m20 1q6-4 12 0" fill="none" stroke="{INK}" stroke-width="1.7"/>'
        if not bird else ""
    )
    body_flourish = ""
    if kind in {"cow", "calf"}:
        body_flourish = (
            f'<path d="M-58-13q8-17 22-12l-6 22-18 4Zm49-20q14-14 27-4l-7 17-22 8Zm57 11q12-9 22 2l-15 17-12-5Z" {STROKE}/>'
        )
    elif kind in {"horse", "pony", "foal", "donkey"}:
        body_flourish = '<path d="M-26-20q26-12 48-2m-42 9q20-9 36-2" fill="none" stroke="#171717" stroke-width="2"/>'
    elif kind in {"pig"}:
        body_flourish = '<path d="M-30-14q15-9 28-2m-22 8q18-6 29 1" fill="none" stroke="#171717" stroke-width="2"/>'
    elif kind in {"duck", "goose", "hen", "rooster", "turkey", "chicken"}:
        body_flourish = '<path d="M-28-14q22-20 43 0-19 18-43 0Z" fill="white" stroke="#171717" stroke-width="2.5"/><path d="m-18-11 20-6" fill="none" stroke="#171717" stroke-width="1.7"/>'
    elif kind in {"sheep", "lamb"}:
        body_flourish = '<path d="M-22-12q12-13 25 0m-22 12q14-13 28 0" fill="none" stroke="#171717" stroke-width="2"/>'
    else:
        body_flourish = '<path d="M-25-14q18-10 34-2m-27 9q14-6 25 0" fill="none" stroke="#171717" stroke-width="2"/>'
    if pose % 3 == 1 and not bird:
        body_flourish += '<path d="M-9-53q-13-15-23-1 8 13 23 1m0 0q14-15 23-1-8 13-23 1m0 0v8" fill="white" stroke="#171717" stroke-width="2.4"/>'
    scarf = ""
    if pose % 5 == 2:
        scarf = '<path d="M20-18q28 13 51 0m-14 2 4 22" fill="none" stroke="#171717" stroke-width="3"/>'
    bow = ""
    if pose % 5 == 1 and not bird:
        bow = '<path d="M-12-54q-15-15-21 0 7 14 21 0m0 0q15-15 21 0-7 14-21 0m0 0v8" fill="white" stroke="#171717" stroke-width="2.5"/>'
    body_transform = f'<g transform="translate({x} {y}) scale({scale * facing} {scale})">'
    inner = (
        f'{tail}{legs}{body}{markings}{body_flourish}{features}'
        f'{head_extra}{scarf}{bow}{eyes}{second_eye}{muzzle}{cheeks}'
    )
    return body_transform + inner + "</g>"


def scene_decoration(scene: dict, index: int) -> str:
    parts = [sun_clouds(index)]
    setting = scene["setting"]
    if setting in {"barn", "yard", "market", "stable"}:
        parts.append(barn())
    if setting in {"orchard", "garden", "field", "hill"}:
        parts.extend([tree(115, 602, 1.05), tree(746, 573, .85)])
    if setting in {"pond", "river", "rain"}:
        parts.append(pond(421, 715, 1.0))
    if setting in {"hay", "stable", "harvest"}:
        parts.extend([hay(660, 704, 1.1), hay(180, 730, .68)])
    if setting in {"barn", "yard", "stable", "orchard", "garden", "field", "hill", "pond", "river", "rain", "hay", "harvest", "market"}:
        parts.append(fence(index))
    parts.append(flowers(index, 868))
    parts.append('<path d="M42 912q190-37 383 0t383 0" fill="none" stroke="#171717" stroke-width="2.5"/>')
    return "".join(parts)


SCENES = [
    {"animal":"cow","name":"Mimosa, a vaquinha","action":"curiosa entre margaridas","setting":"field","pose":0,"x":420,"y":617,"scale":2.65,"facing":1,"prop":'<path d="M559 657q22-29 44 0m-22-1v26" fill="none" stroke="#171717" stroke-width="3"/>'},
    {"animal":"horse","name":"Trovão, o cavalinho","action":"pulando por cima de um tronco","setting":"hill","pose":2,"x":421,"y":606,"scale":2.65,"facing":1,"prop":'<path d="m267 706 118-10m-106 11 12 12m76-23 14 11" fill="none" stroke="#171717" stroke-width="7" stroke-linecap="round"/>'},
    {"animal":"pig","name":"Pipo, o porquinho","action":"brincando numa poça de lama","setting":"pond","pose":3,"x":425,"y":602,"scale":2.7,"facing":1,"prop":'<path d="M280 678q38-27 76 0t76 0m-112 14q30-18 60 0" fill="none" stroke="#171717" stroke-width="3"/>'},
    {"animal":"sheep","name":"Nuvem, a ovelhinha","action":"descansando perto de um monte de feno","setting":"hay","pose":1,"x":405,"y":605,"scale":2.65,"facing":-1,"prop":''},
    {"animal":"rooster","name":"Bento, o galo","action":"cantando para o sol nascer","setting":"barn","pose":0,"x":422,"y":609,"scale":2.65,"facing":1,"prop":'<path d="M358 459q30-30 60 0m-60 12q30-30 60 0" fill="none" stroke="#171717" stroke-width="3"/>'},
    {"animal":"hen","name":"Lola e seus pintinhos","action":"passeando juntinhos pelo quintal","setting":"yard","pose":1,"x":420,"y":593,"scale":2.45,"facing":-1,"prop":animal("chicken",560,730,1.08,-1,2)+animal("chicken",650,745,.88,1,3)},
    {"animal":"duck","name":"Duda, a patinha","action":"nadando com seu barquinho de folha","setting":"pond","pose":2,"x":411,"y":570,"scale":2.6,"facing":1,"prop":'<path d="m537 615 42 0-20 28Z" fill="white" stroke="#171717" stroke-width="3"/><path d="M557 613v-38l26 38" fill="white" stroke="#171717" stroke-width="3"/>'},
    {"animal":"goat","name":"Zeca, o cabritinho","action":"subindo numa pedra no pasto","setting":"hill","pose":0,"x":425,"y":592,"scale":2.65,"facing":1,"prop":'<path d="m270 752 43-59 55 59Z" fill="white" stroke="#171717" stroke-width="3"/>'},
    {"animal":"donkey","name":"Joca, o burrinho","action":"levando uma cesta cheia de maçãs","setting":"orchard","pose":3,"x":423,"y":601,"scale":2.55,"facing":-1,"prop":'<path d="M303 512q50-31 99 0v40h-99Z" fill="white" stroke="#171717" stroke-width="3"/><circle cx="325" cy="511" r="12" fill="white" stroke="#171717" stroke-width="3"/><circle cx="357" cy="506" r="13" fill="white" stroke="#171717" stroke-width="3"/><path d="M325 499v-8m32 2v-8" stroke="#171717" stroke-width="3"/>'},
    {"animal":"rabbit","name":"Tico, o coelhinho","action":"colhendo cenouras na horta","setting":"garden","pose":0,"x":420,"y":627,"scale":2.55,"facing":1,"prop":'<path d="M548 711q-25-42 0-62 26 20 0 62m-4-5 4-50m25 52q-17-30 2-46 22 18-2 46" fill="white" stroke="#171717" stroke-width="3"/>'},
    {"animal":"cat","name":"Mimi, a gatinha","action":"observando uma borboleta curiosa","setting":"garden","pose":1,"x":423,"y":620,"scale":2.55,"facing":1,"prop":'<path d="M557 484q-18-19-35 0 17 17 35 0m0 0q18-19 35 0-17 17-35 0m0 0v17m-3-27-8-19m14 19 9-19" fill="white" stroke="#171717" stroke-width="2.7"/>'},
    {"animal":"dog","name":"Fubá, o cãozinho","action":"ajudando a cuidar do rebanho","setting":"field","pose":2,"x":407,"y":627,"scale":2.45,"facing":1,"prop":animal("lamb",610,632,1.15,-1,2)},
    {"animal":"goose","name":"Gigi, a gansinha","action":"passeando com um guarda-chuva","setting":"rain","pose":1,"x":422,"y":603,"scale":2.55,"facing":1,"prop":'<path d="M540 488q54-62 108 0Zm54 0v183m-17 0h34" fill="white" stroke="#171717" stroke-width="3"/><path d="M551 478q-11-18 0-28m54 28q11-18 0-28" fill="none" stroke="#171717" stroke-width="2.5"/>'},
    {"animal":"turkey","name":"Tobias, o peru","action":"brincando entre folhas de outono","setting":"orchard","pose":0,"x":414,"y":611,"scale":2.5,"facing":1,"prop":'<path d="m550 682 21-45 21 45m-21-45v-17m-21 17 21 16 21-16" fill="white" stroke="#171717" stroke-width="3"/><path d="m580 676 17-39 18 39m-18-39v-14" fill="white" stroke="#171717" stroke-width="3"/>'},
    {"animal":"llama","name":"Lelé, a lhama","action":"usando um cachecol cheio de listras","setting":"hill","pose":2,"x":420,"y":622,"scale":2.5,"facing":1,"prop":'<path d="M508 513q32 20 62 0v29q-30 17-62 0Zm11 4v26m18-22v25m18-29v24" fill="none" stroke="#171717" stroke-width="2.5"/>'},
    {"animal":"calf","name":"Pingo, o bezerrinho","action":"seguindo uma borboleta pelo campo","setting":"field","pose":1,"x":405,"y":617,"scale":2.45,"facing":-1,"prop":'<path d="M542 494q-18-18-34 0 16 17 34 0m0 0q17-18 34 0-16 17-34 0m0 0v18" fill="white" stroke="#171717" stroke-width="2.7"/>'},
    {"animal":"pony","name":"Flor, o pônei","action":"puxando uma charretinha de abóboras","setting":"harvest","pose":3,"x":342,"y":614,"scale":2.2,"facing":1,"prop":'<path d="M509 593h150v73H509Zm20 73v41m109-41v41" fill="white" stroke="#171717" stroke-width="3"/><circle cx="537" cy="671" r="17" fill="white" stroke="#171717" stroke-width="3"/><circle cx="628" cy="671" r="17" fill="white" stroke="#171717" stroke-width="3"/><path d="M550 592q-22-31 5-45 26 14-5 45m40 0q-18-35 8-49 26 20-8 49" fill="white" stroke="#171717" stroke-width="3"/>'},
    {"animal":"lamb","name":"Babi, o cordeirinho","action":"empinando uma pipa no dia de vento","setting":"hill","pose":4,"x":417,"y":626,"scale":2.45,"facing":1,"prop":'<path d="m570 366 49 48-49 48-49-48Zm0 96v120m0-90 37 26m-37-1-28 27" fill="white" stroke="#171717" stroke-width="3"/><path d="m570 364 7-15m-58 63-14-8m100 80 13 9" fill="none" stroke="#171717" stroke-width="2.5"/>'},
    {"animal":"horse","name":"Estrela, a éguinha","action":"passeando com seu potro pela fazenda","setting":"stable","pose":1,"x":352,"y":604,"scale":2.1,"facing":1,"prop":animal("foal",553,672,1.5,1,4)},
    {"animal":"cow","name":"Mimosa e a cesta de flores","action":"descobrindo flores no pomar","setting":"orchard","pose":4,"x":422,"y":618,"scale":2.45,"facing":-1,"prop":'<path d="M555 638h105l-13 69h-79Z" fill="white" stroke="#171717" stroke-width="3"/><path d="M567 638q4-49 41-49t41 49" fill="none" stroke="#171717" stroke-width="3"/><circle cx="580" cy="624" r="9" fill="white" stroke="#171717" stroke-width="2.5"/><circle cx="613" cy="618" r="9" fill="white" stroke="#171717" stroke-width="2.5"/><circle cx="638" cy="628" r="9" fill="white" stroke="#171717" stroke-width="2.5"/>'},
    {"animal":"kid","name":"Nico, o cabritinho curioso","action":"alcançando folhas numa árvore","setting":"garden","pose":2,"x":421,"y":615,"scale":2.5,"facing":1,"prop":'<path d="M567 620v-95m0 25q-36-38-53-16 11 29 53 24m0-12q35-43 57-22-8 34-57 30" fill="none" stroke="#171717" stroke-width="3"/><ellipse cx="511" cy="534" rx="10" ry="6" fill="white" stroke="#171717" stroke-width="2"/><ellipse cx="624" cy="546" rx="10" ry="6" fill="white" stroke="#171717" stroke-width="2"/>'},
    {"animal":"duck","name":"A família dos patinhos","action":"fazendo uma corrida divertida no laguinho","setting":"pond","pose":4,"x":310,"y":584,"scale":1.85,"facing":1,"prop":animal("duck",473,619,1.65,1,1)+animal("duck",615,653,1.45,-1,3)},
    {"animal":"alpaca","name":"Nina, a alpaca","action":"se enfeitando para a festa da fazenda","setting":"market","pose":1,"x":423,"y":625,"scale":2.45,"facing":-1,"prop":'<path d="M520 492q14-22 28 0 14-22 28 0 14-22 28 0v21h-84Z" fill="white" stroke="#171717" stroke-width="3"/><circle cx="541" cy="506" r="4" fill="#171717"/><circle cx="568" cy="506" r="4" fill="#171717"/><circle cx="596" cy="506" r="4" fill="#171717"/>'},
    {"animal":"dog","name":"Fubá e o tratorzinho","action":"ajudando a levar a colheita","setting":"harvest","pose":4,"x":345,"y":634,"scale":2.0,"facing":1,"prop":'<path d="M494 604h102v57H494Zm32-39h39l27 39h-66Z" fill="white" stroke="#171717" stroke-width="3"/><circle cx="516" cy="668" r="22" fill="white" stroke="#171717" stroke-width="4"/><circle cx="586" cy="668" r="16" fill="white" stroke="#171717" stroke-width="4"/><circle cx="516" cy="668" r="6" fill="white" stroke="#171717" stroke-width="2"/><circle cx="586" cy="668" r="5" fill="white" stroke="#171717" stroke-width="2"/>'},
    {"animal":"rooster","name":"A grande festa da fazendinha","action":"com os amigos reunidos para celebrar","setting":"yard","pose":3,"x":352,"y":614,"scale":2.1,"facing":1,"prop":animal("rabbit",524,640,1.45,1,3)+animal("sheep",626,641,1.25,-1,1)},
]


def svg_document(content: str, title: str, color: bool = False) -> str:
    label = escape(title)
    background = '<rect width="850" height="1100" fill="white"/>' if not color else ""
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="8.5in" height="11in" viewBox="0 0 850 1100" role="img" aria-label="{label}">'
        f'<title>{label}</title>{background}{content}</svg>'
    )


def coloring_page(scene: dict, index: int) -> str:
    title = f'{scene["name"]}: {scene["action"]}'
    elements = [
        f'<rect x="50" y="50" width="750" height="1000" rx="28" fill="white" stroke="{INK}" stroke-width="2.5"/>',
        f'<text x="425" y="91" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="28" font-weight="700" fill="{INK}">{escape(scene["name"])}</text>',
        f'<path d="M93 112h664" fill="none" stroke="{INK}" stroke-width="2"/>',
        scene_decoration(scene, index),
        scene["prop"],
        animal(scene["animal"], scene["x"], scene["y"], scene["scale"], scene["facing"], scene["pose"]),
        f'<text x="425" y="1005" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="24" fill="{INK}">{escape(scene["action"])}</text>',
        f'<text x="425" y="1040" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="16" fill="{INK}">Pinte com suas cores favoritas!</text>',
    ]
    return svg_document("".join(elements), title)


def cover_svg() -> str:
    content = """
    <defs>
      <linearGradient id="ceu" x2="0" y2="1"><stop stop-color="#42B8F4"/><stop offset=".62" stop-color="#B9EDFF"/><stop offset="1" stop-color="#FFF1C2"/></linearGradient>
      <linearGradient id="colina" x2="0" y2="1"><stop stop-color="#A7E85F"/><stop offset="1" stop-color="#42B85E"/></linearGradient>
      <linearGradient id="celeiro" x2="0" y2="1"><stop stop-color="#FF8061"/><stop offset="1" stop-color="#E64C55"/></linearGradient>
      <linearGradient id="vaca" x2="0" y2="1"><stop stop-color="#FFFFFF"/><stop offset="1" stop-color="#E9F1F4"/></linearGradient>
      <linearGradient id="feno" x2="0" y2="1"><stop stop-color="#FFE7A0"/><stop offset="1" stop-color="#F6AA61"/></linearGradient>
      <filter id="sombra" x="-.3" y="-.3" width="1.7" height="1.7"><feGaussianBlur stdDeviation="7"/></filter>
    </defs>
    <rect width="850" height="1100" fill="url(#ceu)"/>
    <circle cx="706" cy="320" r="104" fill="#FFE275"/><circle cx="706" cy="320" r="121" fill="#FFF2AE" opacity=".35"/>
    <g fill="#FFF" opacity=".95"><circle cx="91" cy="316" r="34"/><circle cx="127" cy="296" r="48"/><circle cx="168" cy="317" r="34"/><circle cx="553" cy="389" r="26"/><circle cx="584" cy="371" r="38"/><circle cx="618" cy="390" r="27"/></g>
    <path d="M0 503q150-83 298 4t282-8q132-59 270 5v596H0Z" fill="#7DCB69"/>
    <path d="M0 689q205-113 397-20t453-31v462H0Z" fill="url(#colina)"/>
    <path d="M0 802q157-62 323 3t265-8q145-55 262 7v296H0Z" fill="#51BC60"/>
    <g stroke="#67465B" stroke-linejoin="round">
      <path d="M45 624V433l112-87 111 87v191Z" fill="url(#celeiro)" stroke-width="8"/>
      <path d="m25 440 132-105 132 105" fill="none" stroke="#67465B" stroke-width="16"/>
      <path d="M119 624V484q0-17 17-17h23q17 0 17 17v140Z" fill="#FFE69E" stroke-width="7"/>
      <path d="M119 552h57m-29-85v157" fill="none" stroke-width="5"/>
      <path d="M69 471h40v40H69zm146 0h39v40h-39Z" fill="#A4E8FF" stroke-width="6"/>
      <path d="M335 562V431l63-57 63 57v131Z" fill="#F5B34E" stroke-width="7"/>
      <path d="m320 438 78-72 79 72" fill="none" stroke="#67465B" stroke-width="12"/>
      <circle cx="398" cy="430" r="12" fill="#FFF1B6" stroke-width="4"/>
      <path d="M397 430 351 394m47 36 42-49m-42 49 48 32m-48-32-37 47" fill="none" stroke="#FFF1B6" stroke-width="9" stroke-linecap="round"/>
    </g>
    <path d="M0 707h850m-850 42h850" stroke="#FFF2C4" stroke-width="10"/>
    <path d="M44 764v-88m150 88v-88m160 88v-88m160 88v-88m160 88v-88m-630 0q15-29 30 0m150 0q15-29 30 0m160 0q15-29 30 0m160 0q15-29 30 0" fill="none" stroke="#FFF2C4" stroke-width="8" stroke-linecap="round"/>
    <g fill="none" stroke="#32934F" stroke-width="5" stroke-linecap="round"><path d="M60 897v-57m0 33q-23-21-35-9 12 23 35 17m0-16q19-25 34-13-7 24-34 21"/><path d="M778 911v-59m0 33q-22-20-35-9 11 22 35 16m0-15q20-25 35-13-8 24-35 21"/></g>
    <g fill="#FF7187" stroke="#FFF3D1" stroke-width="3"><circle cx="52" cy="839" r="10"/><circle cx="94" cy="861" r="9"/><circle cx="758" cy="850" r="11"/><circle cx="806" cy="871" r="8"/></g>
    <ellipse cx="516" cy="805" rx="178" ry="33" fill="#315B3D" opacity=".22" filter="url(#sombra)"/>
    <!-- Original farm characters in a bright, storybook cover scene. -->
    <g stroke="#5B465B" stroke-width="8" stroke-linecap="round" stroke-linejoin="round">
      <path d="M367 802v73q0 17 18 17h15m78-88v70q0 16 17 16h14m57-88v67q0 16 17 16h16m53-85v63q0 16 17 16h14" fill="none"/>
      <ellipse cx="530" cy="708" rx="157" ry="105" fill="url(#vaca)"/>
      <path d="M414 692q20-40 58-19l-16 51-51 8Zm138-53q42-31 70 3l-21 45-59 0Z" fill="#74677C" stroke-width="6"/>
      <path d="M590 666q16-68 70-56 58 22 38 87-20 54-84 30Z" fill="url(#vaca)"/>
      <path d="M609 619q-34-47-57-19l30 40m78-31q40-43 56-10l-41 47" fill="#FFFFFF"/>
      <ellipse cx="680" cy="714" rx="48" ry="31" fill="#FFD5BF" stroke-width="6"/>
      <ellipse cx="660" cy="711" rx="5" ry="8" fill="#5B465B" stroke="none"/><ellipse cx="698" cy="711" rx="5" ry="8" fill="#5B465B" stroke="none"/>
      <ellipse cx="644" cy="654" rx="14" ry="19" fill="#fff"/><circle cx="648" cy="658" r="7" fill="#382C45" stroke="none"/><circle cx="650" cy="654" r="2.5" fill="#fff" stroke="none"/>
      <ellipse cx="686" cy="651" rx="14" ry="19" fill="#fff"/><circle cx="690" cy="655" r="7" fill="#382C45" stroke="none"/><circle cx="692" cy="651" r="2.5" fill="#fff" stroke="none"/>
      <path d="M657 751q22 18 43-1" fill="none" stroke-width="5"/>
      <path d="M479 603q34 22 65 0m-33 2v37m-17-24q-20-10-28 1m61-1q18-11 27 0" fill="none" stroke-width="5"/>
      <path d="M596 653 579 629m100-11 11-27" fill="none" stroke="#E58477" stroke-width="8"/>
      <ellipse cx="300" cy="824" rx="55" ry="45" fill="#FFE7A0" stroke-width="7"/>
      <circle cx="344" cy="778" r="32" fill="#FFE7A0" stroke-width="7"/>
      <path d="m372 778 34 12-34 13Z" fill="#F59B54" stroke-width="6"/>
      <ellipse cx="351" cy="770" rx="10" ry="13" fill="#fff" stroke-width="3"/><circle cx="354" cy="772" r="5" fill="#382C45" stroke="none"/><circle cx="356" cy="769" r="2" fill="#fff" stroke="none"/>
      <path d="M279 864v35m28-32v32m-28 0-13 9m41-9 12 9" fill="none" stroke-width="7"/>
      <path d="M278 818q17-22 36 0-16 18-36 0Z" fill="#FFB856" stroke-width="4"/>
    </g>
    <g stroke="#67465B" stroke-width="5" stroke-linejoin="round"><path d="M84 808h71l-9 43H93Z" fill="#F6BD57"/><path d="M89 815h61m-66 16h70" fill="none"/><circle cx="97" cy="803" r="14" fill="#F2645A"/><circle cx="127" cy="798" r="15" fill="#F2645A"/><path d="M98 788q4-11 11-10m18 4q6-10 14-8" fill="none" stroke="#3B9555"/></g>
    <g fill="#FFF7D6" stroke="#E67875" stroke-width="3"><circle cx="229" cy="869" r="10"/><circle cx="247" cy="869" r="10"/><circle cx="238" cy="853" r="10"/><circle cx="238" cy="885" r="10"/><circle cx="238" cy="869" r="6" fill="#F4B647"/></g>
    """
    # Keep the cover type large and legible at thumbnail size.
    content += """
    <rect x="53" y="47" width="744" height="230" rx="39" fill="#FFF9E8" stroke="#F16A59" stroke-width="10"/>
    <text x="425" y="117" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="34" font-weight="900" fill="#263A63" stroke="#FFFFFF" stroke-width="2" paint-order="stroke">AVENTURAS NA</text>
    <text x="425" y="210" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="69" font-weight="900" fill="#F15E4E" stroke="#FFFFFF" stroke-width="3" paint-order="stroke">FAZENDINHA</text>
    <path d="M87 332q89-50 178 0-89 66-178 0Z" fill="#FFD743" stroke="#E65B4F" stroke-width="8"/>
    <text x="176" y="326" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="29" font-weight="900" fill="#24345D">25</text>
    <text x="176" y="351" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="14" font-weight="900" fill="#24345D">DESENHOS</text>
    <circle cx="705" cy="363" r="69" fill="#284D9A" stroke="#FFFFFF" stroke-width="7" stroke-dasharray="7 5"/>
    <text x="705" y="350" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="12" font-weight="900" fill="#FFFFFF">IDEAL PARA</text>
    <text x="705" y="380" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="21" font-weight="900" fill="#FFD743">3 A 8 ANOS</text>
    <rect x="120" y="926" width="610" height="105" rx="42" fill="#FFF9E8" stroke="#F16A59" stroke-width="8"/>
    <text x="425" y="971" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="27" font-weight="900" fill="#263A63">25 BICHINHOS PARA COLORIR</text>
    <text x="425" y="1008" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="23" font-weight="900" fill="#EA6152">E SE DIVERTIR!</text>
    <rect x="50" y="1049" width="225" height="42" rx="18" fill="#168BC2" stroke="#FFF" stroke-width="4"/>
    <rect x="296" y="1049" width="254" height="42" rx="18" fill="#50A64E" stroke="#FFF" stroke-width="4"/>
    <rect x="571" y="1049" width="229" height="42" rx="18" fill="#9A55B4" stroke="#FFF" stroke-width="4"/>
    <text x="162" y="1077" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="14" font-weight="900" fill="#FFF">TRAÇOS GROSSOS</text>
    <text x="423" y="1077" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="14" font-weight="900" fill="#FFF">DIVERSÃO E CRIATIVIDADE</text>
    <text x="685" y="1077" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="14" font-weight="900" fill="#FFF">PRESENTE DIVERTIDO</text>
    """
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="8.75in" height="11.25in" viewBox="0 0 875 1125">'
        f'<title>Capa colorida: {escape(TITLE)}</title>{content}</svg>'
    )


def write_png(svg: str, path: Path, width: int = PNG_W, height: int = PNG_H) -> None:
    rendered = cairosvg.svg2png(
        bytestring=svg.encode("utf-8"),
        output_width=width,
        output_height=height,
        dpi=DPI,
    )
    with Image.open(io.BytesIO(rendered)) as image:
        image.save(path, format="PNG", dpi=(DPI, DPI), optimize=True)


def image_data_url(path: Path) -> str:
    if not path.is_file():
        raise FileNotFoundError(f"Imagem de referência não encontrada: {path}")
    mime_types = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}
    mime_type = mime_types.get(path.suffix.lower())
    if mime_type is None:
        raise ValueError(f"Formato de referência não suportado: {path.suffix}")
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    data_url = f"data:{mime_type};base64,{encoded}"
    if len(data_url) > 20_971_520:
        raise ValueError(f"Imagem de referência excede o limite de 20 MB da API: {path}")
    return data_url


def validate_ai_inputs(references: list[Path]) -> None:
    if not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError(
            "Configure OPENAI_API_KEY no ambiente antes de solicitar imagens. "
            "Não coloque a chave neste arquivo nem a envie pelo chat."
        )
    missing = [str(path) for path in references if not path.is_file()]
    if missing:
        raise FileNotFoundError("Imagem(ns) de referência não encontrada(s): " + ", ".join(missing))


def request_ai_image(prompt: str, reference: Path, size: str) -> bytes:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "Configure OPENAI_API_KEY no ambiente antes de solicitar imagens. "
            "Não coloque a chave neste arquivo nem a envie pelo chat."
        )

    payload = {
        "model": AI_MODEL,
        "prompt": prompt,
        "images": [{"image_url": image_data_url(reference)}],
        "size": size,
        "quality": "high",
        "output_format": "png",
        "background": "opaque",
    }
    request = urllib.request.Request(
        "https://api.openai.com/v1/images/edits",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            result = json.load(response)
    except urllib.error.HTTPError as error:
        details = error.read(4000).decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI Images API retornou HTTP {error.code}: {details}") from error

    images = result.get("data") or []
    if not images or not images[0].get("b64_json"):
        raise RuntimeError("A OpenAI Images API não retornou uma imagem em PNG.")
    return base64.b64decode(images[0]["b64_json"], validate=True)


def save_ai_image(image_bytes: bytes, path: Path, width: int, height: int, grayscale: bool) -> None:
    with Image.open(io.BytesIO(image_bytes)) as source:
        image = ImageOps.exif_transpose(source).convert("L" if grayscale else "RGB")
        image = ImageOps.contain(image, (width, height), method=Image.Resampling.LANCZOS)
        background_color = 255 if grayscale else (255, 255, 255)
        background = Image.new(image.mode, (width, height), background_color)
        background.paste(image, ((width - image.width) // 2, (height - image.height) // 2))
        if grayscale:
            background = background.convert("RGB")
        background.save(path, format="PNG", dpi=(DPI, DPI), optimize=True)


def coloring_prompt(scene: dict, index: int) -> str:
    return (
        f"Create one original portrait coloring-book page for children ages 3–8. "
        f"Show {scene['animal']} in a unique, joyful farm scene: {scene['action']}. "
        "Use the supplied image only as broad reference for the clean, charming, detailed "
        "children's coloring-book line-art style. Do not copy its dinosaur, characters, "
        "composition, or objects. Pure white background; crisp black outlines with bold "
        "outer contours and simpler inner details; large enclosed areas that are easy for "
        "small children to color; a few relevant farm details around the character. "
        "No gray, no shading, no hatching, no color, no border, no text, no letters, no "
        "watermark. Keep all important drawing elements comfortably inside the page margins. "
        f"This is distinct illustration {index} of 25; do not reuse another scene."
    )


def cover_prompt() -> str:
    return (
        "Create an original, full-color portrait front-cover illustration for a premium "
        "Brazilian children's farm-animal coloring book for ages 3–8. Use the supplied image "
        "only as broad reference for its polished, expressive, richly colored children's "
        "storybook finish. Do not copy its dinosaurs, characters, composition, or design. "
        "Show a friendly cow, chick, and other original farm-animal friends celebrating "
        "at a sunny farm with a charming barn, rolling green hills, flowers, and layered "
        "details. Bright harmonious colors, appealing expressive faces, clean professional "
        "cartoon illustration, warm and joyful. Leave the top quarter and bottom strip "
        "visually calm and uncluttered for title lettering to be added later. No words, "
        "letters, numbers, logos, or watermark. Keep characters and important details "
        "inside safe margins."
    )


def save_ai_preview(page_number: int, coloring_reference: Path) -> Path:
    scene = SCENES[page_number - 1]
    image = request_ai_image(
        coloring_prompt(scene, page_number),
        coloring_reference,
        "1024x1328",
    )
    preview_dir = OUT / "ai_previews"
    preview_dir.mkdir(parents=True, exist_ok=True)
    preview_path = preview_dir / f"fazendinha_{page_number:02d}_previa.png"
    save_ai_image(image, preview_path, PNG_W, PNG_H, grayscale=True)
    return preview_path


def generate_ai_batch(cover_reference: Path, coloring_reference: Path) -> Path:
    OUT.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="fazendinha-ai-", dir=OUT) as temporary_dir:
        stage = Path(temporary_dir)
        page_paths: list[Path] = []
        for index, scene in enumerate(SCENES, start=1):
            image = request_ai_image(
                coloring_prompt(scene, index),
                coloring_reference,
                "1024x1328",
            )
            path = stage / f"fazendinha_{index:02d}.png"
            save_ai_image(image, path, PNG_W, PNG_H, grayscale=True)
            page_paths.append(path)

        cover_image = request_ai_image(cover_prompt(), cover_reference, "1024x1312")
        cover_path = stage / "capa_frente_com_sangria.png"
        save_ai_image(cover_image, cover_path, 2625, 3375, grayscale=False)

        # Replace deliverables only after every billable request completed successfully.
        PNG_DIR.mkdir(parents=True, exist_ok=True)
        for staged_page in page_paths:
            target = PNG_DIR / staged_page.name
            shutil.copy2(staged_page, target)
        installed_cover = OUT / "capa_frente_com_sangria.png"
        shutil.copy2(cover_path, installed_cover)

    return installed_cover


def make_interior_pdf(paths: list[Path], target: Path) -> None:
    page_w, page_h = PAGE_W_IN * 72, PAGE_H_IN * 72
    pdf = canvas.Canvas(str(target), pagesize=(page_w, page_h), pageCompression=1)
    pdf.setTitle(f"{TITLE} - Miolo para colorir")
    pdf.setAuthor("Astros e Você")
    for image_path in paths:
        pdf.drawImage(ImageReader(str(image_path)), 0, 0, width=page_w, height=page_h, preserveAspectRatio=False, mask="auto")
        pdf.showPage()
        pdf.setFillColor(white)
        pdf.rect(0, 0, page_w, page_h, stroke=0, fill=1)
        pdf.showPage()
    pdf.save()


def make_cover_pdf(
    front_png: Path,
    target: Path,
    pages: int = 50,
    overlay_title: bool = False,
) -> tuple[float, float, float]:
    # KDP white-paper spine formula; the template must be rechecked in KDP before upload.
    spine_in = pages * 0.002252
    width_in = 2 * PAGE_W_IN + spine_in + 0.25
    height_in = PAGE_H_IN + 0.25
    scale = 72
    pdf = canvas.Canvas(str(target), pagesize=(width_in * scale, height_in * scale), pageCompression=1)
    pdf.setTitle(f"{TITLE} - Capa completa KDP")
    pdf.setAuthor("Astros e Você")

    # Back panel has bleed on the left; preserve an empty barcode area.
    back_w, back_h = PAGE_W_IN * scale, PAGE_H_IN * scale
    pdf.setFillColor(HexColor("#D7F3E6"))
    pdf.rect(0, 0, (PAGE_W_IN + 0.125) * scale, height_in * scale, stroke=0, fill=1)
    pdf.setFillColor(HexColor("#8AD8C0"))
    pdf.circle(2.1 * scale, 8.6 * scale, 1.55 * scale, stroke=0, fill=1)
    pdf.setFillColor(HexColor("#FFF4CF"))
    pdf.circle(1.0 * scale, 9.5 * scale, 0.42 * scale, stroke=0, fill=1)
    pdf.setFillColor(HexColor("#365A55"))
    pdf.setFont("Helvetica-Bold", 21)
    pdf.drawString(0.55 * scale, 9.32 * scale, "A fazenda está em festa!")
    pdf.setFont("Helvetica", 13)
    text = pdf.beginText(0.55 * scale, 8.84 * scale)
    text.setLeading(20)
    for line in (
        "Conheça vacas, cavalos, patinhos e muitos",
        "outros amigos nesta coleção de 25 desenhos",
        "originais, feitos para pequenas mãos e",
        "grandes ideias coloridas.",
        "",
        "Pegue seus lápis de cor e venha brincar",
        "na fazendinha!",
    ):
        text.textLine(line)
    pdf.drawText(text)
    pdf.setFillColor(HexColor("#365A55"))
    pdf.setFont("Helvetica-Bold", 11)
    pdf.drawString(0.55 * scale, 5.75 * scale, "Um desenho por folha, com verso em branco.")
    pdf.setFillColor(white)
    pdf.rect(6.375 * scale, 0.35 * scale, 2 * scale, 1.2 * scale, stroke=0, fill=1)

    # Full-bleed front art includes its own 0.125-inch bleed.
    front_x = (PAGE_W_IN + spine_in) * scale
    pdf.drawImage(ImageReader(str(front_png)), front_x, 0, width=8.75 * scale, height=11.25 * scale, preserveAspectRatio=False, mask="auto")
    if overlay_title:
        pdf.setFillColor(HexColor("#FFF9E8"))
        pdf.roundRect(front_x + 0.45 * scale, 9.02 * scale, 7.85 * scale, 1.55 * scale, 0.28 * scale, stroke=0, fill=1)
        pdf.setFillColor(HexColor("#263A63"))
        pdf.setFont("Helvetica-Bold", 20)
        pdf.drawCentredString(front_x + 4.375 * scale, 10.02 * scale, "AVENTURAS NA")
        pdf.setFillColor(HexColor("#F15E4E"))
        pdf.setFont("Helvetica-Bold", 34)
        pdf.drawCentredString(front_x + 4.375 * scale, 9.52 * scale, "FAZENDINHA")
        pdf.setFillColor(HexColor("#263A63"))
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawCentredString(front_x + 4.375 * scale, 0.72 * scale, "25 BICHINHOS PARA COLORIR E SE DIVERTIR!")

    # Spine is intentionally blank; 50 pages is too thin for spine text.
    pdf.setFillColor(HexColor("#E56C5D"))
    pdf.rect((PAGE_W_IN + 0.125) * scale, 0, spine_in * scale, height_in * scale, stroke=0, fill=1)
    pdf.save()
    return width_in, height_in, spine_in


def main() -> None:
    parser = argparse.ArgumentParser(description="Gera o livro de colorir Aventuras na Fazendinha.")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--ai-preview", type=int, metavar="PAGINA", help="Gera uma única página de prévia com a API de imagens.")
    mode.add_argument("--ai-all", action="store_true", help="Gera as 25 páginas e a capa usando a API de imagens.")
    parser.add_argument("--confirm-billable", action="store_true", help="Confirma que as chamadas de geração podem gerar cobranças.")
    parser.add_argument("--cover-reference", type=Path, default=DEFAULT_COVER_REFERENCE)
    parser.add_argument("--coloring-reference", type=Path, default=DEFAULT_COLORING_REFERENCE)
    args = parser.parse_args()

    if len(SCENES) != 25:
        raise RuntimeError(f"Esperadas 25 cenas originais, encontradas {len(SCENES)}.")
    if (args.ai_preview is not None or args.ai_all) and not args.confirm_billable:
        parser.error("A geração de imagens pode gerar custos. Inclua --confirm-billable após conferir os preços da API.")

    if args.ai_preview is not None:
        if not 1 <= args.ai_preview <= len(SCENES):
            parser.error(f"A página deve estar entre 1 e {len(SCENES)}.")
        validate_ai_inputs([args.coloring_reference])
        preview_path = save_ai_preview(args.ai_preview, args.coloring_reference)
        print(f"Prévia gerada: {preview_path}")
        return

    OUT.mkdir(parents=True, exist_ok=True)
    PNG_DIR.mkdir(parents=True, exist_ok=True)
    SVG_DIR.mkdir(parents=True, exist_ok=True)

    ai_cover_path: Path | None = None
    if args.ai_all:
        validate_ai_inputs([args.cover_reference, args.coloring_reference])
        ai_cover_path = generate_ai_batch(args.cover_reference, args.coloring_reference)

    page_pngs: list[Path] = []
    for index, scene in enumerate(SCENES, start=1):
        basename = f"fazendinha_{index:02d}"
        svg = coloring_page(scene, index)
        svg_path = SVG_DIR / f"{basename}.svg"
        png_path = PNG_DIR / f"{basename}.png"
        svg_path.write_text(svg, encoding="utf-8")
        if not args.ai_all:
            write_png(svg, png_path)
        page_pngs.append(png_path)

    cover_source = cover_svg()
    (SVG_DIR / "capa_colorida.svg").write_text(cover_source, encoding="utf-8")
    (OUT / "capa_frente_2550x3300.png").unlink(missing_ok=True)
    cover_png = OUT / "capa_frente_com_sangria.png"
    if not args.ai_all:
        write_png(cover_source, cover_png, 2625, 3375)
    elif ai_cover_path is None:
        raise RuntimeError("A geração de IA não produziu a ilustração da capa.")

    interior_pdf = OUT / "miolo_kdp_50_paginas.pdf"
    make_interior_pdf(page_pngs, interior_pdf)
    cover_pdf = OUT / "capa_completa_kdp_50_paginas.pdf"
    cover_w, cover_h, spine = make_cover_pdf(cover_png, cover_pdf, overlay_title=args.ai_all)

    instructions = OUT / "LEIA-ME.txt"
    instructions.write_text(
        f"""{TITLE}
{SUBTITLE}

ARQUIVOS
- miolo_kdp_50_paginas.pdf: interior 8,5 x 11 pol., 50 páginas, impressão P&B sem sangria.
- capa_completa_kdp_50_paginas.pdf: capa colorida completa para 50 páginas em papel branco; lombada calculada em {spine:.4f} pol.
- capa_frente_com_sangria.png: arte frontal colorida, 2625 x 3375 px, 300 DPI (sangria de 0,125 pol.).
- ilustracoes_png/: 25 páginas originais para colorir, cada uma 2550 x 3300 px, 300 DPI, fundo branco.
- originais_svg/: originais vetoriais das páginas e da capa.

Modo de geração: {"OpenAI Images API (ilustrações rasterizadas)" if args.ai_all else "gerador vetorial local"}.
No modo de IA, os SVGs continuam disponíveis como alternativa vetorial; as páginas PNG e os PDFs
usam as ilustrações geradas pela API. A capa recebe título e subtítulo no PDF para manter o texto legível.

O miolo alterna cada desenho com uma página em branco no verso, para reduzir a marcação
no desenho seguinte ao colorir. As ilustrações ficam dentro de margens seguras e não
usam sangria.

ANTES DE PUBLICAR NO KDP
Confira o PDF na ferramenta de pré-visualização do KDP e gere/compare a capa com o
calculador de capas oficial. A largura de lombada varia conforme o papel e a contagem
de páginas. Estes arquivos assumem brochura, formato 8,5 x 11 pol., interior preto e
branco em papel branco, 50 páginas, miolo sem sangria e capa com sangria de 0,125 pol.
A capa completa mede aproximadamente {cover_w:.4f} x {cover_h:.2f} pol.
O espaço branco de código de barras no verso foi deixado reservado.

O PDF do miolo tem 50 páginas (25 desenhos + 25 versos em branco); isso respeita a
contagem mínima usual para brochura KDP. Não envie as imagens PNG como arquivo de miolo:
use o PDF, e revise cada página no Previewer antes de publicar.
""",
        encoding="utf-8",
    )

    zip_path = ROOT / "aventuras-na-fazendinha-arquivos-kdp.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
        for path in sorted(OUT.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(OUT.parent))
        archive.write(ROOT / "gerar_livro.py", "fontes/gerar_livro.py")
        archive.write(ROOT / "requirements.txt", "fontes/requirements.txt")
        archive.write(ROOT / "INSTRUCOES.md", "fontes/INSTRUCOES.md")

    print(f"Generated {len(page_pngs)} unique coloring pages at {PNG_W}x{PNG_H}, {DPI} DPI.")
    print(f"Interior PDF: {interior_pdf} (50 pages)")
    print(f"Cover PDF: {cover_pdf} ({cover_w:.4f} x {cover_h:.2f} inches; spine {spine:.4f} inches)")
    print(f"Bundle: {zip_path}")


if __name__ == "__main__":
    main()
