# Geração de ilustrações com IA

O gerador mantém o modo vetorial local como padrão. A opção de IA usa a OpenAI Images API
para criar desenhos originais da fazenda, usando as imagens de referência somente como
orientação de estilo. Nenhuma geração é executada automaticamente.

## Prévia de uma página

1. Instale os pacotes do projeto: `python -m pip install -r requirements.txt`.
2. Configure `OPENAI_API_KEY` no ambiente do terminal; não salve a chave no código nem a
   envie por chat.
3. Confira os preços atuais em <https://openai.com/api/pricing/> e execute, a partir desta
   pasta:

   ```sh
   python gerar_livro.py --ai-preview 1 --confirm-billable
   ```

   A prévia será salva em `arquivos/ai_previews/`. Cada chamada à API pode gerar cobrança.

No PowerShell, configure a chave somente para a sessão atual com:

```powershell
$env:OPENAI_API_KEY = "sua-chave"
```

No macOS/Linux:

```sh
export OPENAI_API_KEY="sua-chave"
```

As imagens de referência padrão devem estar na raiz do repositório:

- `Capa_Livro_para_Colorir_Dinossauros.jpg`
- `ChatGPT Image 29 de jul. de 2026, 15_34_52 (1).png`

Para usar outros arquivos, informe `--cover-reference` e `--coloring-reference`.

## Gerar o livro todo

Depois de revisar a prévia e conferir os custos, o lote completo pode ser iniciado com:

```sh
python gerar_livro.py --ai-all --confirm-billable
```

Esse modo faz 26 solicitações (25 páginas para colorir e uma ilustração de capa). Ele
substitui os PNGs do miolo e da capa e recria os PDFs e o ZIP do livro. As imagens são
ajustadas para 2550 × 3300 px ou 2625 × 3375 px, com metadados de 300 DPI. O PDF da capa
recebe o título e o subtítulo localmente para evitar texto gerado ilegível.

Sem as opções `--ai-preview` ou `--ai-all`, o gerador continua usando as ilustrações
vetoriais locais e não faz chamadas à API.
